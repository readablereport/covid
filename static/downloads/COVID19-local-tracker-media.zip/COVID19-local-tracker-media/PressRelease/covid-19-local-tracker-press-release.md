FOR IMMEDIATE RELEASE:  05/06/2020
Stephen Erke
Falcon Laboratories
(309) 839-9490
contact@falconlaboratories.io

**Local Company, Falcon Laboratories, Builds a Public-Facing COVID-19 Tracking Website**

**Peoria, IL**: Falcon Laboratories is excited to release their latest project in an effort to provide the public a resource for local COVID-19 information. The COVID-19 Local Tracker is a local hub that displays stats including confirmed cases, active cases, recovered cases and deaths for county, state and the U.S. It also includes links to local news and it’s all updated in real-time using data from Johns Hopkins and other sources. 

The COVID-19 Local Tracker was created by two Peoria natives Nathan Smith and Stephen Erke. They are co-owners of Falcon Laboratories, which was founded in Peoria. In the past couple of years, both Smith and Erke have been developing Readable Report which is a big data application that makes stats and analytics easy to understand.

“It’s helpful to have a single website to see what’s happening in your community with COVID-19,” says Stephen Erke, Co-owner at Falcon Laboratories. “We were able to use the data engine we’ve built to collect and distill relevant data at the county level.”

The COVID-19 Local Tracker is currently available online at: [covid19.readable.report](https://covid19.readable.report)

**About Readable Report:**
Readable Report is a web application that takes complex data and sends automated, easy-to-read reports. Users gain clear insights across platforms and the ability to make informed decisions. Learn more at readable.report. 


**About Falcon Laboratories:**
Falcon Laboratories is a Peoria-based company that offers front-end and back-end development, app development, as well as web design (UX_UI), graphic_print design and email template creation services. Learn more at  [falconlaboratories.io](http://falconlaboratories.io/) .


###